/**
* @author Bazzite (https://www.bazzite.com)
* @license MIT License Copyright (c) 2018 Bazzite
*/

export default {
    // General
    TRANSACTIONS: 'Transacciones',
    CARDS: 'Tarjetas',
    MENU: 'MenÃº',

    sidedrawer: {
        balance: 'Saldo',
        english: 'English',
        spanish: 'EspaÃ±ol',
        madeBy: 'Hecho con â¤ï¸ por ',
    },

    balance: {
        income: 'INGRESOS',
        expenses: 'GASTOS',
        balance: 'SALDO',
    },

    cards: {
        title: 'Tarjetas'
    },

    categories: {
        home: 'Hogar',
        transport: 'Transporte',
        communication: 'ComunicaciÃ³n',
        hotel: 'Hotel',
        restaurant: 'Restaurante'
    },

    detail: {
        status: {
            completed: 'Completado',
            pending: 'Pendiente',
        }
    }
}