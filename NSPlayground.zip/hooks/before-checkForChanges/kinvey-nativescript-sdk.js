module.exports = require("kinvey-nativescript-sdk/nativescript-hook-scripts/before-checkForChanges.js");
