package com.spc.sapientchallenge.controller;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spc.sapientchallenge.exception.ReportException;
import com.spc.sapientchallenge.model.ResponseBean;
import com.spc.sapientchallenge.model.TranscationDetails;
import com.spc.sapientchallenge.utils.ReportsUtils;

@RestController
public class ReportController {

    @RequestMapping("/")
    public String getHome() {

        return " <h1>Application is started and working Fine! </h1>";
    }

    @RequestMapping("/report")
    public String getReport() throws ReportException, IOException, ParseException {

        ArrayList<String> fileList;
        String htmlStart = null;

        fileList = (ArrayList<String>) ReportsUtils.getFileNamesFromFolder();

        List<TranscationDetails> transcationDetails = ReportsUtils.readDatafromFile(fileList);

        List<ResponseBean> responseBean = ReportsUtils.getProcessingFeeCalcuaction(transcationDetails);
        htmlStart = ReportsUtils.generateHTML(responseBean);

        return htmlStart;
    }
}
