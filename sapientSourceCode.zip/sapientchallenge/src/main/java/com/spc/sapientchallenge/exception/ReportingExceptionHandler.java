package com.spc.sapientchallenge.exception;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice(basePackages = "com.spc.sapientchallenge")
public class ReportingExceptionHandler {
    @ExceptionHandler(ReportException.class)
    public ResponseEntity<RestErrorInfo> notFoundException(final ReportException e, HttpServletRequest request) {
        return error(e, HttpStatus.NOT_FOUND, "", request);
    }

    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<RestErrorInfo> notFoundException(HttpServletRequest request, HttpServletResponse response) {
        ReportException ex = new ReportException("2001");
        return error(ex, HttpStatus.BAD_REQUEST, "", request);
    }

    private ResponseEntity<RestErrorInfo> error(final ReportException exception, final HttpStatus httpStatus,
            final String logRef, HttpServletRequest request) {
        try {
            System.out.println("In errrrrr");
            return new ResponseEntity<RestErrorInfo>(
                    new RestErrorInfo(exception.getErrorCode(), exception.getErrorMessage()), httpStatus);
        } catch (Exception e) {
            return new ResponseEntity<RestErrorInfo>(new RestErrorInfo(exception.getErrorCode(), "en-US"), httpStatus);
        }
    }
}
