package com.spc.sapientchallenge.model;

import java.util.Date;
public class TranscationDetails {

    private String externalTransactionId;
    private String clientId;
    private String securityId;
    private String transactionType;
    private Date transactionDate;

    private String marketValue;
    private String priorityFlag;

    public String getExternalTransactionId() {
        return externalTransactionId;
    }

    public void setExternalTransactionId(String externalTransactionId) {
        this.externalTransactionId = externalTransactionId;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getSecurityId() {
        return securityId;
    }

    public void setSecurityId(String securityId) {
        this.securityId = securityId;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getMarketValue() {
        return marketValue;
    }

    public void setMarketValue(String marketValue) {
        this.marketValue = marketValue;
    }

    public String getPriorityFlag() {
        return priorityFlag;
    }

    public void setPriorityFlag(String priorityFlag) {
        this.priorityFlag = priorityFlag;
    }

    public Date getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(Date transactionDate) {
        this.transactionDate = transactionDate;
    }

    @Override
    public String toString() {
        return "External Transaction Id: '" + this.externalTransactionId + "', Client Id: '" + this.clientId
                + "', Security Id: '" + this.securityId + "', Transaction Type: '" + this.transactionType
                + "', Transaction Date: '" + this.transactionDate + "', Market Value: '" + this.marketValue
                + "', Priority Flag: '" + this.priorityFlag + "'";
    }

}
