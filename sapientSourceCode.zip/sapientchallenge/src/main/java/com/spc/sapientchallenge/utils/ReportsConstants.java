package com.spc.sapientchallenge.utils;

public class ReportsConstants {
    public static String filePath = "/files/";

}
