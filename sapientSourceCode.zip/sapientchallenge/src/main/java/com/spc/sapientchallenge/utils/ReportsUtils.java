package com.spc.sapientchallenge.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.spc.sapientchallenge.exception.ReportException;
import com.spc.sapientchallenge.model.ResponseBean;
import com.spc.sapientchallenge.model.TranscationDetails;

public class ReportsUtils {

    public static List<String> getFileNamesFromFolder() throws IOException, ReportException {

        List<String> listOffiles = new ArrayList<String>();
        String filepath = new File("").getAbsolutePath();

        File folder = new File(filepath + ReportsConstants.filePath);
        File[] fileList = folder.listFiles();
        if (fileList.length == 0) {
            throw new ReportException("1002 : ",
                    "No File To pasrse please place file in path :: " + filepath + ReportsConstants.filePath);
        }

        for (int i = 0; i < fileList.length; i++) {
            listOffiles.add(fileList[i].getName());
        }

        return listOffiles;
    }

    public static List<TranscationDetails> readDatafromFile(List<String> fileNames)
            throws ParseException, ReportException {
        String filepath = new File("").getAbsolutePath();
        List<TranscationDetails> transactionDetailsList = new ArrayList<TranscationDetails>();
        for (String fileName : fileNames) {
            String fileNameWithPath = filepath + ReportsConstants.filePath + fileName;

            String fileNameExt[] = fileName.split("\\.");

            if (fileNameExt[1].equals("csv")) {
                readCsvFile(fileNameWithPath, transactionDetailsList);
            }

        }

        return transactionDetailsList;
    }

    private static List<TranscationDetails> readCsvFile(String fileName,
            List<TranscationDetails> transactionDetailsList) throws ParseException, ReportException {
        try {
            BufferedReader br = null;
            String line = "";
            String splitBy = ",";
            try {
                br = new BufferedReader(new FileReader(fileName));
                while ((line = br.readLine()) != null) {

                    String[] parser = line.split(splitBy);
                    if (!line.contains("External Transaction Id")) {
                        TranscationDetails transcationDetails = new TranscationDetails();
                        transcationDetails.setExternalTransactionId(parser[0]);
                        transcationDetails.setClientId(parser[1]);
                        transcationDetails.setSecurityId(parser[2]);
                        transcationDetails.setTransactionType(parser[3]);
                        transcationDetails.setTransactionDate(convertStringToDate(parser[4]));
                        transcationDetails.setMarketValue(parser[5]);
                        transcationDetails.setPriorityFlag(parser[6]);
                        transactionDetailsList.add(transcationDetails);
                    }

                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (br != null) {
                    try {
                        br.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        } catch (Exception e) {
            throw new ReportException("1003 : ", "Error In Data or file corrupted!");
        }
        return transactionDetailsList;
    }

    private static List<TranscationDetails> readXlsxFile(String fileName,
            List<TranscationDetails> transactionDetailsList) {

        // Xlsx Parsing logic can be written in this method
        return transactionDetailsList;
    }

    public static List<ResponseBean> getProcessingFeeCalcuaction(List<TranscationDetails> transcationDetailsList)
            throws ParseException {

        Map<String, ResponseBean> normalTransaction = new HashMap<String, ResponseBean>();
        Map<String, ResponseBean> intraDayTransaction = new HashMap<String, ResponseBean>();
        List<ResponseBean> responseBean = new ArrayList<ResponseBean>();
        for (TranscationDetails transcationDetails : transcationDetailsList) {

            if (!(transcationDetails.getTransactionType().equals("SELL")
                    || transcationDetails.getTransactionType().equals("BUY"))) {
                String key = transcationDetails.getClientId() + "-" + transcationDetails.getSecurityId() + "-"
                        + transcationDetails.getTransactionType() + "-" + transcationDetails.getPriorityFlag() + "-"
                        + convertDateToString(transcationDetails.getTransactionDate());

                if (normalTransaction.containsKey(key)) {

                    ResponseBean normalTransactionResponseBean = normalTransaction.get(key);
                    if (transcationDetails.getPriorityFlag().equals("Y")) {
                        normalTransactionResponseBean
                                .setProcessingFee(normalTransactionResponseBean.getProcessingFee() + 500.00);
                    } else if (transcationDetails.getPriorityFlag().equals("N")
                            && transcationDetails.getTransactionType().equals("SELL")
                            || transcationDetails.getTransactionType().equals("WITHDRAW")) {
                        normalTransactionResponseBean
                                .setProcessingFee(normalTransactionResponseBean.getProcessingFee() + 100.00);
                    } else if (transcationDetails.getPriorityFlag().equals("N")
                            && transcationDetails.getTransactionType().equals("BUY")
                            || transcationDetails.getTransactionType().equals("DEPOSIT")) {
                        normalTransactionResponseBean
                                .setProcessingFee(normalTransactionResponseBean.getProcessingFee() + 50.00);
                    }
                    normalTransaction.remove(key);
                    normalTransaction.put(key, normalTransactionResponseBean);
                } else {

                    ResponseBean normalTransactionResponseBean = new ResponseBean();
                    normalTransactionResponseBean.setClientId(transcationDetails.getClientId());
                    normalTransactionResponseBean.setPriority(transcationDetails.getPriorityFlag());
                    normalTransactionResponseBean
                            .setTransactionDate(convertDateToStringForOutput(transcationDetails.getTransactionDate()));
                    normalTransactionResponseBean.setTransactionType(transcationDetails.getTransactionType());

                    if (transcationDetails.getPriorityFlag().equals("Y")) {
                        normalTransactionResponseBean
                                .setProcessingFee(normalTransactionResponseBean.getProcessingFee() + 500.00);
                    } else if (transcationDetails.getPriorityFlag().equals("N")
                            && transcationDetails.getTransactionType().equals("SELL")
                            || transcationDetails.getTransactionType().equals("WITHDRAW")) {
                        normalTransactionResponseBean
                                .setProcessingFee(normalTransactionResponseBean.getProcessingFee() + 100.00);
                    } else if (transcationDetails.getPriorityFlag().equals("N")
                            && transcationDetails.getTransactionType().equals("BUY")
                            || transcationDetails.getTransactionType().equals("DEPOSIT")) {
                        normalTransactionResponseBean
                                .setProcessingFee(normalTransactionResponseBean.getProcessingFee() + 50.00);
                    }

                    normalTransaction.put(key, normalTransactionResponseBean);
                }

            } else {

                String key = transcationDetails.getClientId() + "-" + transcationDetails.getSecurityId() + "-"
                        + transcationDetails.getPriorityFlag() + "-"
                        + convertDateToString(transcationDetails.getTransactionDate()) + "-"
                        + transcationDetails.getTransactionType();
                String searchKey = transcationDetails.getClientId() + "-" + transcationDetails.getSecurityId() + "-"
                        + transcationDetails.getPriorityFlag() + "-"
                        + convertDateToString(transcationDetails.getTransactionDate()) + "-";
                if (transcationDetails.getTransactionType().equals("SELL")) {
                    searchKey = searchKey + "BUY";
                } else if (transcationDetails.getTransactionType().equals("BUY")) {
                    searchKey = searchKey + "SELL";
                }

                if (intraDayTransaction.containsKey(searchKey)) {

                    ResponseBean intraDayPairTransaction = intraDayTransaction.get(searchKey);

                    if (transcationDetails.getTransactionDate()
                            .equals(convertStringToDate(intraDayPairTransaction.getTransactionDate()))) {

                        ResponseBean intraDayTransactionResponseBean = new ResponseBean();
                        intraDayTransactionResponseBean.setClientId(transcationDetails.getClientId());
                        intraDayTransactionResponseBean.setPriority(transcationDetails.getPriorityFlag());
                        intraDayTransactionResponseBean.setTransactionDate(
                                convertDateToStringForOutput(transcationDetails.getTransactionDate()));
                        intraDayTransactionResponseBean.setTransactionType(transcationDetails.getTransactionType());
                        intraDayTransactionResponseBean.setSecurityId(transcationDetails.getSecurityId());
                        intraDayTransactionResponseBean.setProcessingFee(10.00);
                        intraDayTransaction.put(searchKey, intraDayTransactionResponseBean);

                        responseBean.add(intraDayTransactionResponseBean);
                        responseBean.add(intraDayPairTransaction);

                        intraDayTransaction.remove(searchKey);
                        intraDayTransaction.remove(key);

                    }

                } else {

                    ResponseBean intraDayTransactionResponseBean = new ResponseBean();
                    intraDayTransactionResponseBean.setClientId(transcationDetails.getClientId());
                    intraDayTransactionResponseBean.setPriority(transcationDetails.getPriorityFlag());
                    intraDayTransactionResponseBean
                            .setTransactionDate(convertDateToStringForOutput(transcationDetails.getTransactionDate()));
                    intraDayTransactionResponseBean.setTransactionType(transcationDetails.getTransactionType());

                    intraDayTransactionResponseBean.setProcessingFee(10.00);
                    intraDayTransactionResponseBean.setSecurityId(transcationDetails.getSecurityId());
                    intraDayTransaction.put(key, intraDayTransactionResponseBean);
                }

            }

        }

        for (ResponseBean mapResponseBean : intraDayTransaction.values()) {

            String key = mapResponseBean.getClientId() + "-" + mapResponseBean.getSecurityId() + "-"
                    + mapResponseBean.getTransactionType() + "-" + mapResponseBean.getPriority() + "-"
                    + convertDateToString(convertStringToDate(mapResponseBean.getTransactionDate()));

            if (normalTransaction.containsKey(key)) {

                ResponseBean normalTransactionResponseBean = normalTransaction.get(key);

                if (mapResponseBean.getPriority().equals("Y")) {
                    mapResponseBean.setProcessingFee(normalTransactionResponseBean.getProcessingFee() + 500.00);
                } else if (mapResponseBean.getPriority().equals("N")
                        && mapResponseBean.getTransactionType().equals("SELL")
                        || mapResponseBean.getTransactionType().equals("WITHDRAW")) {
                    mapResponseBean.setProcessingFee(normalTransactionResponseBean.getProcessingFee() + 100.00);
                } else if (mapResponseBean.getPriority().equals("N")
                        && mapResponseBean.getTransactionType().equals("BUY")
                        || mapResponseBean.getTransactionType().equals("DEPOSIT")) {
                    mapResponseBean.setProcessingFee(normalTransactionResponseBean.getProcessingFee() + 50.00);
                }
                normalTransaction.remove(key);

                normalTransaction.put(key, mapResponseBean);
            } else {

                ResponseBean responseMapper = new ResponseBean();
                responseMapper.setClientId(mapResponseBean.getClientId());
                responseMapper.setPriority(mapResponseBean.getPriority());
                responseMapper.setTransactionDate(mapResponseBean.getTransactionDate());
                responseMapper.setTransactionType(mapResponseBean.getTransactionType());

                if (mapResponseBean.getPriority().equals("Y")) {
                    responseMapper.setProcessingFee(500.00);
                } else if (mapResponseBean.getPriority().equals("N")
                        && mapResponseBean.getTransactionType().equals("SELL")
                        || mapResponseBean.getTransactionType().equals("WITHDRAW")) {
                    responseMapper.setProcessingFee(100.00);
                } else if (mapResponseBean.getPriority().equals("N")
                        && mapResponseBean.getTransactionType().equals("BUY")
                        || mapResponseBean.getTransactionType().equals("DEPOSIT")) {
                    responseMapper.setProcessingFee(50.00);
                }

                normalTransaction.put(key, responseMapper);
            }
        }

        for (ResponseBean current : normalTransaction.values()) {

            responseBean.add(current);
        }

        return responseBean;

    }

    public static String generateHTML(List<ResponseBean> responseBean) {

        String htmlStart = "<table  border='1' > <tr> <th>Client Id</th> <th>Transaction Type</th> <th>Transaction Date</th><th>Priority</th><th>Processing Fee</th></tr>";
        String htmlEnd = "</table> ";
        String content = "";

        for (int i = 0; i < responseBean.size(); i++) {
            content += "<tr> " + "<td>" + responseBean.get(i).getClientId() + "</td>" + "<td>"
                    + responseBean.get(i).getTransactionType() + "</td>" + "<td>"
                    + responseBean.get(i).getTransactionDate() + "</td>" + "<td>" + responseBean.get(i).getPriority()
                    + "</td>" + "<td>" + responseBean.get(i).getProcessingFee() + "</td>";

        }

        return htmlStart + content + htmlEnd;

    }

    private static Date convertStringToDate(String strDate) throws ParseException {

        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
        return formatter.parse(strDate);

    }

    private static String convertDateToString(Date date) throws ParseException {
        DateFormat dateFormat = new SimpleDateFormat("MMddyyyy");
        String strDate = dateFormat.format(date);

        return strDate;
    }

    private static String convertDateToStringForOutput(Date date) throws ParseException {
        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        String strDate = dateFormat.format(date);

        return strDate;
    }

}
