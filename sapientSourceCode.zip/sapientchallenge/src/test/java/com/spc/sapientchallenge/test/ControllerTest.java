package com.spc.sapientchallenge.test;



import static org.junit.Assert.assertTrue;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.spc.sapientchallenge.controller.ReportController;
import com.spc.sapientchallenge.main.ApplicationStartup;



@RunWith(SpringRunner.class)
@SpringBootTest(classes = ApplicationStartup.class)
public class ControllerTest {

	 @BeforeClass
	    public static void setup() {
		 
	 }
	@Autowired
	 private ReportController reportController;
	 
	 @Test
	    public void getReportTest() throws Exception {
		 String test =reportController.getReport();
		 assertTrue(test != null );
	}
	 
	 
	 @Test
	    public void getHomeTest() throws Exception {
		 String test =reportController.getHome();
		 assertTrue(test.equals(" <h1>Application is started and working Fine! </h1>"));
	 }
}
