package com.spc.sapientchallenge.test;

import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.spc.sapientchallenge.main.ApplicationStartup;
import com.spc.sapientchallenge.model.ResponseBean;
import com.spc.sapientchallenge.model.TranscationDetails;
import com.spc.sapientchallenge.utils.ReportsUtils;




@RunWith(SpringRunner.class)
@SpringBootTest(classes = ApplicationStartup.class)
public class ReportsUtilsTest {

	static List<ResponseBean> responseBeanList =new ArrayList<ResponseBean>();
	static List<TranscationDetails> transcationDetailsList = new ArrayList<TranscationDetails>();
	static String date = "09/10/2019";
	 @BeforeClass
	    public static void setup() {
		 ResponseBean responseBean = new ResponseBean();
		 responseBean.setClientId("GS");
		 responseBean.setPriority("Y");
		 responseBean.setProcessingFee(101.9);
		 responseBean.setSecurityId("ICICI");
		 responseBean.setTransactionDate("11/23/2013");
		 responseBean.setTransactionType("BUY");
		 responseBeanList.add(responseBean);
		 
		 
		 TranscationDetails transcationDetails = new TranscationDetails();
		 transcationDetails.setClientId("GS");
		 transcationDetails.setExternalTransactionId("SAPEXTXN1");
		 transcationDetails.setMarketValue("101.9");
		 transcationDetails.setPriorityFlag("Y");
		 transcationDetails.setSecurityId("ICICI");
		 Date date1 = null;
		try {
			date1 = new SimpleDateFormat("MM/dd/yyyy").parse(date);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		 transcationDetails.setTransactionDate(date1);
		 transcationDetails.setTransactionType("BUY");
		 transcationDetailsList.add(transcationDetails);
	 }
	 
	 
	 @Test
	    public void getReportTest() throws Exception {
		 
		 String test =ReportsUtils.generateHTML(responseBeanList);
		 
		 String returnHTML="<table  border='1' > <tr> <th>Client Id</th> <th>Transaction Type</th> <th>Transaction Date</th><th>Priority</th><th>Processing Fee</th></tr><tr> <td>GS</td><td>BUY</td><td>11/23/2013</td><td>Y</td><td>101.9</td></table> ";
		 if(test != null){
		Assert.assertEquals(returnHTML,test);	 
		 }else {
			 Assert.fail();
		 }
	}
	
	 //convertStringToDate
	  
	 @Test
	    public void getProcessingFeeCalcuactionTest() throws Exception {
		 List<ResponseBean> responseBeanList =ReportsUtils.getProcessingFeeCalcuaction(transcationDetailsList);
		 if(responseBeanList != null){
				Assert.assertEquals(responseBeanList.get(0).getClientId(),"GS");	 
				Assert.assertEquals(responseBeanList.get(0).getPriority(),"Y");
				double pFee = 500.00;
				Assert.assertEquals(responseBeanList.get(0).getProcessingFee(),pFee,0);
				
				Assert.assertEquals(responseBeanList.get(0).getTransactionDate(),date);
				Assert.assertEquals(responseBeanList.get(0).getTransactionType(),"BUY");
				
				
		 }else {
					 Assert.fail();
				 }
	 }
	 
}

